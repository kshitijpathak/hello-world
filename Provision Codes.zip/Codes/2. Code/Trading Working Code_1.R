########### CODE TO CREATE CASHFLOW DATA - TRADING ##############

## Set filepaths/variables
wrk.dir = "C:/Users/kshitij.pathak/OneDrive - OakNorth Bank/Desktop/OneDrive - OakNorth Bank/Kshitij/ONB Work/6. Quarterly Provisions/1. Trading/2. June 2022/Codes/"
input.dir = "1. Input/"
output.dir = "3. Output/"

Analysis_Date <- as.Date("2022-05-31",format = "%Y-%m-%d")

#Define libraries
library(readxl)
library(dplyr)
library(xlsx)
library(stringr)
library(zoo)
library(date)
library(lubridate)

## Update file names
# loanbook = "1. Input/Loan Book Summary - As of 2021.10.31.xlsx"
# loanfile = "1. Input/Input PD LGD Feb'22.xlsx"
# cashflowfile ="1. Input/Loanbook 28th Feb.xlsx"

calc.Provs <- function(loanfile,cashflowfile){
  
  ## Read all files
  # loanbookdata = read_xlsx(path = paste0(paste0(getwd(),"//",loanbook)), sheet = "Detailed Data")
  cashflowdata = read_xlsx(path = paste0(wrk.dir,input.dir,cashflowfile))
  cashflowdata = cashflowdata[,-1]
  input_data = read_xlsx(path = paste0(wrk.dir,input.dir,loanfile))
  
  ## Prepare cashflow data
  CF = merge(input_data,cashflowdata,by.x = "Loan ID", by.y = "ID")
  due.dt.col = match("DUEDATE",colnames(CF))
  princp.col = match("Principal Repayment",colnames(CF))
  intrst.col = match("Interest Repayment",colnames(CF))
  CF = CF[,c(1:due.dt.col,princp.col,intrst.col)]
  CF <- CF[order(CF[,"Group Name"],CF[,"DUEDATE"]), ]
  CF$DUEDATE <- as.Date(CF$DUEDATE, "%m/%d/%Y")
  CF$DAYS <- as.numeric(CF$DUEDATE - Analysis_Date) 
  
  CF_PR=aggregate(`Principal Repayment`~`Loan ID`+DUEDATE, data=CF, FUN=sum) 
  CF_IR=aggregate(`Interest Repayment`~`Loan ID`+DUEDATE, data=CF, FUN=sum)
  
  CF_1=merge(CF_PR,CF_IR)
  
  CF_1 =CF_1 [!duplicated(CF_1[c(1,2)]),]
  
  CF <- CF[-c(16,17)]
  
  CF = CF[!duplicated(CF[c(1,15)]),]
  
  CF <- merge(CF_1,CF)
  
  CF$CASHFLOW <- CF$`Principal Repayment`+CF$`Interest Repayment`
  
  # write.csv(CF,paste0(output.dir,"CF.csv"))
  
  # View(CF)
  
  for (i in 1:nrow(CF)) {
    
    if (i==1) {
      
      CF$TimeINyears[i]= CF$DAYS[i]/365.25
    }
    else
      
      CF$TimeINyears[i] = ifelse(test = (CF$`Loan Stage (IFRS)`[i] == 1),yes = ifelse(test = ((CF$`Loan ID`[i]==CF$`Loan ID`[i-1]) & (CF$DAYS[i]>365) & (CF$DAYS[i-1]<365)),yes = 1,no = CF$DAYS[i]/365.25),no = CF$DAYS[i]/365.25)
    
  }
  
  CF$Discount_Factor = 1/((1+((CF$`Interest rate`)/100))^(CF$TimeINyears))
  
  CF$Discounted_Cashflow = CF$Discount_Factor*CF$CASHFLOW
  
  library(plyr)
  
  CountLoans <- count(CF$`Loan ID`)
  
  ###CPD CALCULATIONS
  
  CPDCalc= merge(CF, CountLoans, by.x = "Loan ID",by.y= "x" , all.x = TRUE)
  
  CPDCalc$CPD_Q1= 1-(1-CPDCalc$`CumShockPD-Q1`)^(CPDCalc$TimeINyears/0.25)
  
  CPDCalc$CPD_Q2 = CPDCalc$`CumShockPD-Q1`+ ((CPDCalc$`CumShockPD-Q2`- CPDCalc$`CumShockPD-Q1`)/(0.5-0.25))*(CPDCalc$TimeINyears-0.25)
  
  CPDCalc$CPD_Q3 = CPDCalc$`CumShockPD-Q2`+ ((CPDCalc$`CumShockPD-Q3`- CPDCalc$`CumShockPD-Q2`)/(0.75-0.5))*(CPDCalc$TimeINyears-0.5)                                 
  
  CPDCalc$CPD_Q4 = CPDCalc$`CumShockPD-Q3`+ ((CPDCalc$`CumShockPD-Q4`- CPDCalc$`CumShockPD-Q3`)/(0.75-0.5))*(CPDCalc$TimeINyears-0.75)
  
  CPDCalc$CPD_2Y = 1-(((1-CPDCalc$`CumShockPD-2nd yr`)/(1-CPDCalc$`CumShockPD-Q4`))^(CPDCalc$TimeINyears-1))*(1-CPDCalc$`CumShockPD-Q4`)
  
  CPDCalc$CPD_3Y = 1-(((1-CPDCalc$`CumShockPD-3rd yr`)/(1-CPDCalc$`CumShockPD-2nd yr`))^(CPDCalc$TimeINyears-2))*(1-CPDCalc$`CumShockPD-2nd yr`)
  
  CPDCalc$CPD_4Y = 1-(((1-CPDCalc$`CumShockPD-4th yr`)/(1-CPDCalc$`CumShockPD-3rd yr`))^(CPDCalc$TimeINyears-3))*(1-CPDCalc$`CumShockPD-3rd yr`)
  
  CPDCalc$CPD_5Y = 1-(((1-CPDCalc$`CumShockPD-5th yr`)/(1-CPDCalc$`CumShockPD-4th yr`))^(CPDCalc$TimeINyears-4))*(1-CPDCalc$`CumShockPD-4th yr`)
  
  CPDCalc$CPD_CurrentPeriod = ifelse(CPDCalc$freq==1 & CPDCalc$TimeINyears >1, CPDCalc$`CumShockPD-Q4`, 
                                     ifelse(CPDCalc$TimeINyears<=0.25, CPDCalc$CPD_Q1,
                                            ifelse(CPDCalc$TimeINyears>0.25 & CPDCalc$TimeINyears<=0.5, CPDCalc$CPD_Q2,
                                                   ifelse(CPDCalc$TimeINyears>0.5 & CPDCalc$TimeINyears<=0.75, CPDCalc$CPD_Q3,
                                                          ifelse(CPDCalc$TimeINyears>0.75 & CPDCalc$TimeINyears<=1, CPDCalc$CPD_Q4,
                                                                 ifelse(CPDCalc$TimeINyears>1 & CPDCalc$TimeINyears<=2, CPDCalc$CPD_2Y,
                                                                        ifelse(CPDCalc$TimeINyears>2 & CPDCalc$TimeINyears<=3, CPDCalc$CPD_3Y,
                                                                               ifelse(CPDCalc$TimeINyears>3 & CPDCalc$TimeINyears<=4, CPDCalc$CPD_4Y,CPDCalc$CPD_5Y))))))))
  
  for (i in 1:nrow(CPDCalc)) {
    
    CPDCalc$MPD_current_period[i] <- ifelse(i == 1,as.numeric(CPDCalc$CPD_CurrentPeriod[i]),ifelse(CPDCalc$`Loan ID`[i] == CPDCalc$`Loan ID`[i-1],as.numeric(CPDCalc$CPD_CurrentPeriod[i])-as.numeric(CPDCalc$CPD_CurrentPeriod[i-1]),as.numeric(CPDCalc$CPD_CurrentPeriod[i]))
    )  
  }
  
  # Compute GCV
  
  for (i in 1:nrow(CPDCalc)) {
    
    CPDCalc$GCV[i] <- sum(CPDCalc$Discounted_Cashflow[CPDCalc$TimeINyears >= CPDCalc$TimeINyears[i] & CPDCalc$`Loan ID` == CPDCalc$`Loan ID`[i]])
    
  }
  
  # Compute ECL
  
  CPDCalc$ECL <- CPDCalc$MPD_current_period*CPDCalc$`LGD-moodys`*CPDCalc$GCV
  
  
  Summ <- function(x, y){
    sum(CPDCalc[CPDCalc$`Loan ID` == x & CPDCalc$TimeINyears <= y, "ECL"])
  }
  
  CPDCalc$ECL1Y <- mapply(Summ, CPDCalc$`Loan ID`, 1)
  
  CPDCalc$ECLIYF= ifelse(CPDCalc$freq==1, CPDCalc$ECL, CPDCalc$ECL1Y)
  
  CPDCalc$ECLIYF= ifelse(CPDCalc$ECLIYF==0 & CPDCalc$`Loan Stage (IFRS)`==1, CPDCalc$ECL, CPDCalc$ECLIYF)
  
  CPDCalc$ECL1Y = NULL
  
  Summ <- function(x){
    sum(CPDCalc[CPDCalc$`Loan ID` == x , "ECL"])
  }
  
  CPDCalc$ECL_Lifetime= mapply(Summ, CPDCalc$`Loan ID`)
  
  # write.csv(CPDCalc, paste0(output.dir,"Cashflow_Newformula.csv"))
  
  # Remove duplicated rows based on Group Name from Cash Flow File
  
  Unique_Prov_calc <- CPDCalc[!duplicated(CPDCalc$`Loan ID`),c(1:37)]
  OutStandingBalance = aggregate(x = CPDCalc$`Principal Repayment`,by = list(CPDCalc$`Loan ID`), sum)
  colnames(OutStandingBalance) <- c("Loan ID","OutStandingBalance")
  Unique_Prov_calc = merge(Unique_Prov_calc,OutStandingBalance,all=T)
  
  # write.csv(Unique_Prov_calc,paste0(output.dir, "Unique_Prov_calc_Newformula.csv"))
  
  #write.csv(Unique_Prov_calc, "Unique_Prov_calc_oldformula.csv")
  
  #END
  return(list(cash_flow = CF,intr_calc = CPDCalc ,final_provs = Unique_Prov_calc))
}

input_files = list.files(paste0(wrk.dir,input.dir))

loanfile = input_files[grep("Input",input_files)]
cashflowfile = input_files[grep("Loanbook",input_files)]
inp.file.name = gsub(".xlsx","",loanfile)
j=1
for(i in loanfile){
  prov_results = calc.Provs(i,cashflowfile)
  
  write.csv(prov_results$cash_flow,paste0(wrk.dir,output.dir,inp.file.name[j],"_Loan ID level Cash flow.csv"))
  write.csv(prov_results$intr_calc,paste0(wrk.dir,output.dir,inp.file.name[j],"_Loan ID+date Level Provisions.csv"))
  write.csv(prov_results$final_provs,paste0(wrk.dir,output.dir,inp.file.name[j], "_Loan ID level Provisions.csv"))
  j=j+1
}
