
# packageurl <- "https://cran.r-project.org/src/contrib/Archive/RSelenium/RSelenium_1.7.0.tar.gz"
# install.packages(packageurl, repos=NULL, type="source")
# remove.packages("RSelenium")
library(RSelenium)
library(netstat)
library(wdman)
library(magrittr)
library(stringr)

# Set user-id Password

userId = "kshitijpathak1996@gmail.com"
password = "June@2022.#"

# Product to open
prod_link = "https://www.amazon.in/Notebook-Display-i5-11300H-Graphics-Fingerprint/dp/B098XL8VSM/?_encoding=UTF8&pd_rd_w=plAuI&content-id=amzn1.sym.ee853eb9-cee5-4961-910b-2f169311a086&pf_rd_p=ee853eb9-cee5-4961-910b-2f169311a086&pf_rd_r=QQNKZBG141WVG8F0NVK1&pd_rd_wg=0lW21&pd_rd_r=c3a6932b-4bb9-4c99-86e2-3e1c0d72da18&ref_=pd_gw_ci_mcx_mr_hp_atf_m"

# create driver object - Normal mode
# driver <- rsDriver(
#   browser = "chrome"
#   ,port = free_port()
#   ,chromever = "103.0.5060.53"
#   ,extraCapabilities = eCaps
# )

freeport = free_port()

wdman::selenium(port = freeport, browser = "chrome",
             chromever = "103.0.5060.53",check=FALSE, retcommand = TRUE) %>%
  system(wait=FALSE, invisible=FALSE,)

remDr = remoteDriver(extraCapabilities = list(marionette = TRUE
                                              ,chromeOptions = list(args = list("--incognito")))
                     ,browserName="chrome"
                     ,port = freeport)

# Function to close all ports
# system("taskkill /im java.exe /f", intern=FALSE, ignore.stdout=FALSE)

# Open browser window
remDr$open()

remDr$maxWindowSize()

# navigate to Amazon's homepage
remDr$navigate("https://www.amazon.in/ap/signin?openid.pape.max_auth_age=0&openid.return_to=https%3A%2F%2Fwww.amazon.in%2F%3F_encoding%3DUTF8%26ref_%3Dnav_ya_signin&openid.identity=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.assoc_handle=inflex&openid.mode=checkid_setup&openid.claimed_id=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0%2Fidentifier_select&openid.ns=http%3A%2F%2Fspecs.openid.net%2Fauth%2F2.0&")

webElem <- remDr$findElement(using = "name",value = "email")
webElem$sendKeysToElement(list(userId))

remDr$findElement(using = "id",value = "continue")$clickElement()

webElem_pass <- remDr$findElement(using = "id",value = "ap_password")
webElem_pass$sendKeysToElement(list(password))

remDr$findElement(using = "id",value = "auth-signin-button")$clickElement()

# Open product link
remDr$navigate(prod_link)

remDr$findElement(using = "id",value = "add-to-cart-button")$clickElement()

cart_link = "https://www.amazon.in/gp/cart/view.html?ref_=nav_cart"

remDr$navigate(cart_link)

remDr$findElement(using = "id",value = "sc-buy-box-ptc-button")$clickElement()

#adress selection
remDr$findElement(using = "name",value = "submissionURL")$clickElement()

remDr$findElement(using = "id", value = "shipToThisAddressButton")$clickElement()

# select payment method - Net banking





